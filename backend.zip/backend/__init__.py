
def seed():
    return None